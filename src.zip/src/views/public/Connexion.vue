<template>
    <div class="content">
      <h1>Vous êtes sur la page : Connexion</h1>
    </div>
  
</template>
  
<script>
  export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name: 'Connexion'
  }
</script>
  