<template>
  <div>
    <LoginForm :show="showLoginForm" @login-success="handleLogin" />
    <router-view></router-view>
  </div>
</template>

<script>
import LoginForm from "@/components/public/LoginForm.vue";

export default {
  name: 'App',
  components: {LoginForm},
  watch: {
    '$i18n.locale': function (newVal) {
      localStorage.setItem('user.locale', newVal)
    }
  },
  data() {
    return {
      userRole: null
    };
  },
  methods: {
    handleLogin(role) {
      this.userRole = role;
    }
    // Autres méthodes...
  }
}
</script>

<style>
  /* Reset du style par défaut et ajout de styles de base */
  body, h1, h2, h3, p, ul, li {
    margin: 0;
    padding: 0;
  }

  body {
    font-family: 'Arial', sans-serif;
  }


  /* Material Symbols */
  @font-face {
    font-family: 'Material Symbols';
    font-style: normal;
    font-weight: 400;
    src: url(@/assets/fonts/MaterialSymbolsRounded.woff2) format('woff2');
  }

  .material-symbols {
  font-family: 'Material Symbols';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;  /* Preferred icon size */
  display: inline-block;
  line-height: 1;
  text-transform: none;
  letter-spacing: normal;
  word-wrap: normal;
  white-space: nowrap;
  direction: ltr;
}
</style>
