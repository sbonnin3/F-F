export default {
    en: {...require('./en.lang')},
    fr: {...require('./fr.lang')}
}